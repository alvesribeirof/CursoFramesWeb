//importando o lodash
const _ = require('lodash');

//importando o user de outro módulo (arquivo)
const User = require('../user/user');

//mais uma função middleware responsavel por sumarizar os usuários
function getSummary(req, res) {
    //função do mongoose
    User.aggregate({
            //passa os documentos apenas com campos especificados para a proxima fase
            //do fluxo de agregação
            $project: {
                name: 1,
                user: 1
            }
        }, {
            //agrupa os documentos por algum tipo de expressão especificada e a saida
            //passa para a proxima fase do documento usando critério distinct
            $group: {
                _id: null,
                name: 1,
                user: 1
            }
        }, {
            ////passa os documentos apenas com campos especificados para a proxima fase
            //do fluxo de agregação ignorando o  _id necessário no group
            $project: { _id: 0, name: 1, user: 1 }
        },
        //função de callback
        function(error, result) {
            if (error) {
                res.status(500).json({ errors: [error] });
            } else {
                res.json(_.defaults(result[0], { name: 0, user: 0 }));
            }
        });
}

//exportando a função getSummary através da sintaxe reduzida ECMAScript 2015
//ou ECMAScript 6
module.exports = { getSummary };