//retirando a declaração do controller do escopo global e atribuindo a uma função
//seguindo boas práticas de John Papa
(function() {
    //declaração do controller do UserControllerCtrl
    angular.module('primeiraApp').controller('UserControllerCtrl', [
        '$http', //injeção de depedência
        '$location', //injeção de depedência
        'msgs', //injeção de depedência 
        'tabs', //injeção de depedência
        UserController //referência da função declarada abaixo
    ]);

    //declarando a função do controller
    function UserController($http, $location, msgs, tabs) {
        //vm recebe o objeto da propria função dentro do escopo
        const vm = this;
        //constante que aponta para a URL da API
        const url = 'http://localhost:3003/api/users';

        //reseta o cadastro e zera os usuários
        vm.refresh = function() {
            //atribuindo a paginação para a constante page 
            //onde se for inválido pegue por padrão a página 1
            const page = parseInt($location.search().page) || 1;

            //recuperando os registros do banco de dados de 6 em 6
            $http.get(`${url}?skip=${(page - 1) * 6}&limit=6`).then(function(response) {
                vm.user = { users: [{}] }; //zerando o atributo usuários
                vm.users = response.data; //resposta obtida do get feita na url que retorna um array de usuários
                vm.calculateValues(); //chamada à função de cálculos dos valores                

                //paginando os elementos do banco
                $http.get(`${url}/count`).then(function(response) {
                    //armazenando a quantidade de páginas que serão exibidas
                    //através da função matematica que divide o valor por 6 e o metodo ceil arredonda o valor
                    vm.pages = Math.ceil(response.data.value / 6);
                    tabs.show(vm, { tabList: true, tabCreate: true }); //passando os estados das abas ativadas
                });
            });
        };

        //função que faz uma requisição http para a API Rest do backend
        //para obter criar de todos os usuários da aplicação
        vm.create = function() {
            //se a requisição retornar com sucesso é chamada a função
            $http.post(url, vm.user).then(function(response) {
                vm.refresh(); //chamada à função de atualizar os usuários
                msgs.addSuccess('Usuário inserido com sucesso!!');
                //se retornar erro 
            }).catch(function(response) {
                msgs.addError(response.data.errors);
            });
        };

        //função que recebe como parametro o objeto selecionado
        vm.showTabView = function(user) {
            vm.user = user; //variavel do controle recebe o parametro que form vai ler
            vm.calculateValues(); //chamada à função de cálculos dos valores
            tabs.show(vm, { tabView: true }); //mostrando somente a tabUpdate
        };

        //função que recebe como parametro o objeto selecionado
        vm.showTabUpdate = function(user) {
            vm.user = user; //variavel do controle recebe o parametro que form vai ler
            vm.calculateValues(); //chamada à função de cálculos dos valores
            tabs.show(vm, { tabUpdate: true }); //mostrando somente a tabUpdate
        };
        //função que recebe como parametro o objeto selecionado
        vm.showTabDelete = function(user) {
            vm.user = user; //variavel do controle recebe o parametro que form vai ler
            vm.calculateValues(); //chamada à função de cálculos dos valores
            tabs.show(vm, { tabDelete: true }); //mostrando somente a tabDelete
        };

        //função que altera os dados da linha selecionada
        vm.update = function() {
            //declarando a const que conterá a url do backend juntamente com o _id do elemento a ser alterado
            const updateUrl = `${url}/${vm.user._id}`;
            //passagem de dados para a alteração com sucesso do elemento
            $http.put(updateUrl, vm.user).then(function(response) {
                vm.refresh(); //volte para lista e inclusão
                msgs.addSuccess('Alteração de usuário realizada com sucesso!');
            }).catch(function(response) { //caso dê erro retorna a msg de erro
                msgs.addError(response.data.errors);
            });
        };

        //função que deleta os dados da linha selecionada
        vm.delete = function() {
            //declarando a const que conterá a url do backend juntamente com o _id do elemento a ser excluido
            const deleteUrl = `${url}/${vm.user._id}`;
            //passagem de dados para a exclusão com sucesso do elemento
            $http.delete(deleteUrl, vm.user).then(function(response) {
                vm.refresh(); //volte para lista e inclusão                
                msgs.addSuccess('Exclusão de usuário realizada com sucesso!');
            }).catch(function(response) { //caso dê erro retorna a msg de erro
                msgs.addError(response.data.errors);
            });
        };

        //declarando a função de cálculo de valores 
        vm.calculateValues = function() {
            vm.name = {}; //definindo as variáveis iguais a 0
            vm.username = {};

            //se valores válidos
            if (vm.user) {
                //para cada extração de nome e usuário via destructured dos usuários
                vm.user.users.forEach(function({ name, username }) {
                    //atribuição aditiva via expressão ternária onde 
                    //se o valor não existir (!name) retorna vazio como padrão
                    //caso contrário, retorna o nome completo e o nome de usuário
                    vm.name += !name ? {} : name;
                    vm.username += !username ? {} : username;
                });
            }
        };

        vm.refresh(); //chamada à função de atualizar os usuários
    }
})();