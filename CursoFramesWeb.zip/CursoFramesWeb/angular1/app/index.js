//declarando o angular com nome da aplicação e as depedências
angular.module('primeiraApp', [
    'ui.router', //responsável pelas rotas
    'ngAnimate', //responsável pelas animações
    'toastr' //responsável pelas mensagens
]);