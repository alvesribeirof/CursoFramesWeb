//modulo para expor a api para a aplicação
const restful = require('node-restful');

//manipulação do banco de dados mongodb
const mongoose = restful.mongoose;

//Mapeamento do schema do ciclo de pagamento e validação dos atributos
const UsersSchema = new mongoose.Schema({
    name: { type: String, required: [true, 'Informe o Nome Completo!'] },
    username: { type: String, unique: true, required: [true, 'Informe o Usuário!'] },
    password: { type: String, required: [true, 'Informe a senha!'] }
});

//exportando o model User do schema userSchema
module.exports = restful.model('User', UsersSchema);