//retirando a declaração do controller do escopo global e atribuindo a uma função
//seguindo boas práticas de John Papa
(function() {
    //declaração do controller do UserControllerCtrl
    angular.module('primeiraApp').controller('LoginControllerCtrl', [
        '$http', //injeção de depedência
        'msgs', //injeção de depedência 
        'tabs', //injeção de depedência
        LoginController //referência da função declarada abaixo
    ]);

    //declarando a função do controller
    function LoginController($http, msgs, tabs) {
        //vm recebe o objeto da propria função dentro do escopo
        const vm = this;

        vm.verificarAutenticacao = function verificarAutenticacao(req, res, next) {
            if (req.url == '/dashboard') {
                var authOk = false;
                var auth = req.headers['authorization'];
                console.log(">>> Header: " + auth);

                if (auth) {

                    var b64 = new Buffer(auth.substring(6), 'base64');
                    var sobj = b64.toString();
                    var objeto = JSON.parse(sobj);
                    console.log(">>> Conteudo: " + JSON.stringify(objeto));
                    if (objeto.username == "fulano" &&
                        objeto.senha == "teste") {
                        console.log(">>> OK");
                        authOk = true;
                    }
                }
                if (!authOk) {
                    console.log(">>> Falha!");
                    res.json(401, "erro");
                } else {
                    return next();
                }
            } else {
                return next();
            }
        };

        vm.login = function(req, res) {
            var username = req.body.username;
            var password = req.body.password;

            //constante que aponta para a URL da API
            const url = 'http://localhost:3003/api/users';

            if (vm.username == username && vm.password == password) {

            }



        };
    }
})();